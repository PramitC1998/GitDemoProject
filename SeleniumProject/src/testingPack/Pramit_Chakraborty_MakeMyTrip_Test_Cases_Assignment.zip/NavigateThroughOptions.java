package testingPack;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class NavigateThroughOptions {

	@Test
	public void navigate() throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.makemytrip.com/");
        //driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    WebElement moreMenu = driver.findElement(By.xpath("/html/body/div/div/div[1]/div[1]/div[2]/div/div/nav/ul/li[1]/a/span[2]"));
	    moreMenu.click();
	    WebDriverWait wait = new WebDriverWait(driver,40);
	    try {
	    	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/div/div[2]/p/a")));
	        WebElement PrinterElement=driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div/div[2]/p/a"));
	        PrinterElement.click();
	    }
	    catch(NoSuchElementException e) {
	    	System.out.println("No such element");
	    }
	    Thread.sleep(2000);
	    driver.navigate().back();
	}

}
